import os
import glob
import pandas as pd
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm

pd.set_option('display.max_columns', None)

# =========================
# CONFIG
# =========================
BASE_XML_DIR = r'H:\equifax final code\equifax_reports\credit_bureau\equifax_reports'
MASTER_ZIP = r"E:\CB Report Download S3\CCR\2026\feb26\Equifax Summary Report (Credit Bureau Report Date-Wise) (CCR)_Feb26.zip"

START_DATE = datetime(2026, 2, 1)
END_DATE   = datetime(2026, 2, 28)

OUTPUT_RETAIL_CSV = r"E:\CB Report Download S3\final_data_upload_to_S3\2026\feb26\Equifax_retail_feb_2026.csv"
OUTPUT_MFI_CSV    = r"E:\CB Report Download S3\final_data_upload_to_S3\2026\feb26\Equifax_mfi_feb_2026.csv"

MAX_WORKERS = 25
BUREAU_TYPE = "EquiFax"

# =========================
# LOAD MASTER DATA
# =========================
masterData = pd.read_csv(MASTER_ZIP, sep="|")
masterData['DOCUMENT PATH Req'] = masterData['DOCUMENT PATH'].str.split("/")

def get_xml_path(path_list):
    try:
        return list(path_list)[4].replace('.html', '.xml')
    except Exception:
        return None

masterData['DOCUMENT PATH XMl NAME'] = masterData['DOCUMENT PATH Req'].apply(get_xml_path)

ENTITY_NO_MAP = dict(
    zip(masterData['DOCUMENT PATH XMl NAME'], masterData['ENTITY NO'])
)

ENTITY_TYPE_MAP = dict(
    zip(masterData['DOCUMENT PATH XMl NAME'], masterData['ENTITY TYPE'])
)

ENTITY_customer_MAP = dict(
    zip(masterData['DOCUMENT PATH XMl NAME'], masterData['CUSTOMER NO'])
)


# =========================
# XML HELPERS
# =========================
def parse_history(history_node, namespace, fmt):
    if history_node is None:
        return ''

    output = []
    for month in history_node.findall('sch:Month', namespace):
        key = month.attrib.get('key', '')
        try:
            key = datetime.strptime(key, fmt).strftime("%b-%Y")
        except Exception:
            pass

        dpd = month.findtext('sch:DaysPastDue', default='', namespaces=namespace)
        asset = month.findtext('sch:AssetClassificationStatus', default='', namespaces=namespace)
        output.append(f"{key},{dpd}/{asset}")

    return '|'.join(output)


def parse_credit_report(xml_string, account_number, entity_type, customer_no, bureau_type):
    if not xml_string:
        return None, None

    try:
        root = ET.fromstring(xml_string)
    except ET.ParseError:
        return None, None

    namespace = {'sch': 'http://services.equifax.com/eport/ws/schemas/1.0'}

    def txt(el, default=''):
        return el.text.strip() if el is not None and el.text else default

    def flt(el, default=0.0):
        try:
            return float(el.text)
        except Exception:
            return default
        
    # ===============================
    # Inquiry Response Header
    # ===============================
    header = root.find('.//sch:InquiryResponseHeader', namespace)

    inquiry_date = txt(header.find('sch:Date', namespace)) if header is not None else ''
    inquiry_time = txt(header.find('sch:Time', namespace)) if header is not None else ''


    score_detail = root.find('.//sch:ScoreDetails/sch:ScoreDetail', namespace)
    bureau_score = txt(score_detail.find('sch:Value', namespace)) if score_detail is not None else None

    personal_info = root.find('.//sch:PersonalInfo', namespace)
    if personal_info is None:
        return None, None

    common = {
        'Application ID': account_number,
        'ENTITY_TYPE': entity_type, 
        'CUSTOMER NO': customer_no,
        'co_applicant_relation': 'not found',
        'bureau_type': bureau_type,

        # 🔹 Inquiry header fields
        'InquiryDate': inquiry_date,
        'InquiryTime': inquiry_time,

        'FullName': txt(personal_info.find('sch:Name/sch:FullName', namespace)),
        'DateOfBirth': txt(personal_info.find('sch:DateOfBirth', namespace)),
        'Gender': txt(personal_info.find('sch:Gender', namespace)),
        'Age': txt(personal_info.find('sch:Age/sch:Age', namespace)),
        'BureauScore': bureau_score
    }


    retail, mfi = [], []

    # -------- RETAIL --------
    for acc in root.findall('.//{*}Accounts/{*}Retails/{*}Account'):
        row = common.copy()
        row.update({
            'AccountCategory': 'Retail',
            'AccountNumber': txt(acc.find('sch:AccountNumber', namespace)),
            'Institution': txt(acc.find('sch:Institution', namespace)),
            'AccountType': txt(acc.find('sch:AccountType', namespace)),
            'OwnershipType': txt(acc.find('sch:OwnershipType', namespace)),
            'Balance': flt(acc.find('sch:Balance', namespace)),
            'PastDueAmount': flt(acc.find('sch:PastDueAmount', namespace)),
            'SanctionAmount': flt(acc.find('sch:SanctionAmount', namespace)),
            'InstallmentAmount': flt(acc.find('sch:InstallmentAmount', namespace)),
            'InterestRate': txt(acc.find('sch:InterestRate', namespace)),
            'RepaymentTenure': txt(acc.find('sch:RepaymentTenure', namespace)),
            'TermFrequency': txt(acc.find('sch:TermFrequency', namespace)),
            'AccountStatus': txt(acc.find('sch:AccountStatus', namespace)),
            'AssetClassification': txt(acc.find('sch:AssetClassification', namespace)),
            'DateOpened': txt(acc.find('sch:DateOpened', namespace)),
            'DateReported': txt(acc.find('sch:DateReported', namespace)),
            'LastPaymentDate': txt(acc.find('sch:LastPaymentDate', namespace)),
            'PaymentHistory': parse_history(
                acc.find('sch:History48Months', namespace),
                namespace,
                "%m-%y"
            )
        })
        retail.append(row)

    # -------- MICROFINANCE --------
    for acc in root.findall('.//{*}Accounts/{*}Microfinances/{*}Account'):
        row = common.copy()
        row.update({
            'AccountCategory': 'Microfinance',
            'AccountNumber': txt(acc.find('sch:AccountNumber', namespace)),
            'Institution': txt(acc.find('sch:Institution', namespace)),
            'CurrentBalance': flt(acc.find('sch:CurrentBalance', namespace)),
            'DisbursedAmount': flt(acc.find('sch:DisbursedAmount', namespace)),
            'AppliedAmount': flt(acc.find('sch:AppliedAmount', namespace)),
            'SanctionAmount': flt(acc.find('sch:SanctionAmount', namespace)),
            'InstallmentAmount': flt(acc.find('sch:InstallmentAmount', namespace)),
            'RepaymentTenure': txt(acc.find('sch:RepaymentTenure', namespace)),
            'LoanCategory': txt(acc.find('sch:LoanCategory', namespace)),
            'LoanPurpose': txt(acc.find('sch:LoanPurpose', namespace)),
            'LoanCycleID': txt(acc.find('sch:LoanCycleID', namespace)),
            'AccountStatus': txt(acc.find('sch:AccountStatus', namespace)),
            'DaysPastDue': txt(acc.find('sch:DaysPastDue', namespace)),
            'DateOpened': txt(acc.find('sch:DateOpened', namespace)),
            'DateReported': txt(acc.find('sch:DateReported', namespace)),
            'LastPaymentDate': txt(acc.find('sch:LastPaymentDate', namespace)),
            'PaymentHistory': parse_history(
                acc.find('sch:History24Months', namespace),
                namespace,
                "%m-%y"
            )
        })
        mfi.append(row)

    return retail, mfi


# =========================
# FILE COLLECTION
# =========================
def collect_xml_files(base_dir, start_date, end_date):
    xml_files = []
    current = start_date

    while current <= end_date:
        folder = current.strftime("%d%m%Y")
        folder_path = os.path.join(base_dir, folder)

        if os.path.exists(folder_path):
            xml_files.extend(glob.glob(os.path.join(folder_path, "*.xml")))

        current += timedelta(days=1)

    return xml_files


# =========================
# WORKER
# =========================
def process_single_file(file_path):
    name = os.path.basename(file_path)

    account_number = ENTITY_NO_MAP.get(name)
    entity_type    = ENTITY_TYPE_MAP.get(name)
    customer_no = ENTITY_customer_MAP.get(name)

    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            xml_data = f.read()

        return parse_credit_report(
            xml_data,
            account_number,
            entity_type,      # 👈 pass ENTITY TYPE
            customer_no,
            BUREAU_TYPE
        )

    except Exception:
        return None, None



# =========================
# MAIN
# =========================
if __name__ == "__main__":

    files = collect_xml_files(BASE_XML_DIR, START_DATE, END_DATE)

    print(f"\n📅 Date range : {START_DATE:%d-%m-%Y} to {END_DATE:%d-%m-%Y}")
    print(f"📄 Total XML files found: {len(files):,}\n")

    all_retail, all_mfi = [], []

    with ProcessPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = [executor.submit(process_single_file, f) for f in files]

        for future in tqdm(
            as_completed(futures),
            total=len(futures),
            desc="Processing XML files",
            unit="file"
        ):
            retail, mfi = future.result()

            if retail:
                all_retail.extend(retail)
            if mfi:
                all_mfi.extend(mfi)

    # =========================
    # SAVE OUTPUT
    # =========================
    retail_df = pd.DataFrame(all_retail)
    mfi_df = pd.DataFrame(all_mfi)

    if not retail_df.empty:
        retail_df.to_csv(OUTPUT_RETAIL_CSV, sep='|', index=False)

    if not mfi_df.empty:
        mfi_df.to_csv(OUTPUT_MFI_CSV, sep='|', index=False)

    print("\n✅ COMPLETED SUCCESSFULLY")
    print(f"🛒 Retail records saved       : {len(retail_df):,}")
    print(f"🏦 Microfinance records saved : {len(mfi_df):,}")