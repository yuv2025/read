import os
import time
import glob
import traceback
import pandas as pd
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm

pd.set_option("display.max_columns", None)

# =========================
# CONFIG
# =========================
BASE_XML_DIR = r"H:\highmark_final_code\highmark_reports\credit_bureau\highmark_reports"

MASTER_ZIP = r"E:\CB Report Download S3\CCR\2026\feb26\Highmark Summary Report (Credit Bureau Report Date-Wise) (CCR)_Feb26.zip"

OUTPUT_FILE = r"E:\CB Report Download S3\final_data_upload_to_S3\2026\feb26\Highmark_XML_Parsed_feb26.csv"

START_DATE = datetime(2026, 2, 1)
END_DATE   = datetime(2026, 2, 28)

BUREAU_TYPE = "Highmark"

# MAX_WORKERS = 50
# BATCH_SIZE  = 20000
MAX_WORKERS = 22
BATCH_SIZE  = 20000


# =========================
# FIXED CSV HEADER (DO NOT CHANGE)
# =========================
CSV_COLUMNS = [
    "file_path",
    "application_id",
    "entity_type",
    "CUSTOMER NO",
    "co_applicant_relation",
    "bureau_type",
    "date_of_request",
    "dob",
    "age",
    "score",
    "lender_name",
    "account_number",
    "credit_guarantor",
    "account_type",
    "date_reported",
    "ownership_indicator",
    "account_status",
    "disbursed_amount",
    "disbursed_date",
    "last_payment_date",
    "closed_date",
    "installment_amount",
    "overdue_amount",
    "write_off_amount",
    "current_balance",
    "security_status",
    "original_term",
    "combined_payment_history",
    "matched_type",
    "suit_filed_wilful_default",
    "actual_payment",
    'installment_frequency'
]


# =========================
# LOAD MASTER DATA
# =========================
masterData = pd.read_csv(MASTER_ZIP, sep="|", dtype=str)

masterData["DOCUMENT PATH Req"] = masterData["DOCUMENT PATH"].str.split("/")

def get_xml_name(path_list):
    try:
        return list(path_list)[-1].replace(".html", ".xml")
    except Exception:
        return None

masterData["XML_NAME"] = masterData["DOCUMENT PATH Req"].apply(get_xml_name)

ENTITY_NO_MAP = dict(
    zip(masterData['XML_NAME'], masterData['ENTITY NO'])
)

ENTITY_TYPE_MAP = dict(
    zip(masterData['XML_NAME'], masterData['ENTITY TYPE'])
)

ENTITY_customer_MAP = dict(
    zip(masterData['XML_NAME'], masterData['CUSTOMER NO'])
)



RELATION_MAP = {}
if "CO_APPLICANT_RELATION" in masterData.columns:
    RELATION_MAP = dict(
        zip(masterData["XML_NAME"], masterData["CO_APPLICANT_RELATION"])
    )

# =========================
# XML PARSER
# =========================
def parse_xml(xml_file_path, application_id, co_applicant_relation, entity_type, customer_no):

    records = []

    try:
        date_of_request = ""
        score = ""

        current_dob = ""
        current_age = ""
        current_mfi = ""

        def strip_ns(tag):
            return tag.split("}", 1)[-1] if "}" in tag else tag

        for _, elem in ET.iterparse(xml_file_path, events=("end",)):
            tag = strip_ns(elem.tag)

            # ---------- HEADER ----------
            if tag == "HEADER":
                for c in elem:
                    if strip_ns(c.tag) == "DATE-OF-REQUEST":
                        date_of_request = c.text or ""
                elem.clear()

            # ---------- SCORE ----------
            elif tag == "SCORE":
                for c in elem:
                    if strip_ns(c.tag) == "SCORE-VALUE":
                        score = c.text or ""
                elem.clear()

            # =====================================================
            # STRUCT 2 : INDV-RESPONSE
            # =====================================================
            elif tag == "INDV-RESPONSE":
                current_dob = ""
                current_age = ""
                current_mfi = ""

                for c in elem:
                    ct = strip_ns(c.tag)

                    if ct == "DOB":
                        current_dob = c.text or ""
                    elif ct == "AGE":
                        current_age = c.text or ""
                    elif ct == "MFI":
                        current_mfi = c.text or ""

                    elif ct == "LOAN-DETAIL":
                        row = dict.fromkeys(CSV_COLUMNS, "")
                        row.update({
                            "file_path": xml_file_path,
                            "application_id": application_id,
                            "entity_type": entity_type,
                            'CUSTOMER NO': customer_no,
                            "co_applicant_relation": co_applicant_relation,
                            "bureau_type": BUREAU_TYPE,

                            "date_of_request": date_of_request,
                            "dob": current_dob,
                            "age": current_age,
                            "score": score,

                            "credit_guarantor": current_mfi,

                            "account_number": c.findtext("ACCT-NUMBER", ""),
                            "account_type": c.findtext("ACCT-TYPE", ""),
                            "account_status": c.findtext("STATUS", ""),
                            "date_reported": c.findtext("INFO-AS-ON", ""),
                            "disbursed_date": c.findtext("DISBURSED-DT", ""),
                            "closed_date": c.findtext("CLOSED-DT", ""),

                            "disbursed_amount": c.findtext("DISBURSED-AMT", ""),
                            "installment_amount": c.findtext("INSTALLMENT-AMT", ""),
                            "overdue_amount": c.findtext("OVERDUE-AMT", ""),
                            "write_off_amount": c.findtext("WRITE-OFF-AMT", ""),
                            "current_balance": c.findtext("CURRENT-BAL", ""),

                            "combined_payment_history": c.findtext(
                                "COMBINED-PAYMENT-HISTORY", ""
                            ),
                            "installment_frequency": c.findtext("FREQ", ""),
                        })

                        records.append(row)

                elem.clear()

            # =====================================================
            # STRUCT 1 : RESPONSE → LOAN-DETAILS
            # =====================================================
            elif tag == "LOAN-DETAILS":
                row = dict.fromkeys(CSV_COLUMNS, "")
                row.update({
                    "file_path": xml_file_path,
                    "application_id": application_id,
                    "entity_type": entity_type,
                    'CUSTOMER NO': customer_no,
                    "co_applicant_relation": co_applicant_relation,
                    "bureau_type": BUREAU_TYPE,

                    "date_of_request": date_of_request,
                    "score": score,

                    "credit_guarantor": elem.findtext("CREDIT-GUARANTOR", ""),

                    "account_number": elem.findtext("ACCT-NUMBER", ""),
                    "account_type": elem.findtext("ACCT-TYPE", ""),
                    "ownership_indicator": elem.findtext("OWNERSHIP-IND", ""),
                    "account_status": elem.findtext("ACCOUNT-STATUS", ""),
                    "date_reported": elem.findtext("DATE-REPORTED", ""),
                    "disbursed_date": elem.findtext("DISBURSED-DATE", ""),
                    "last_payment_date": elem.findtext("LAST-PAYMENT-DATE", ""),
                    "closed_date": elem.findtext("CLOSED-DATE", ""),

                    "disbursed_amount": elem.findtext("DISBURSED-AMT", ""),
                    "installment_amount": elem.findtext("INSTALLMENT-AMT", ""),
                    "actual_payment": elem.findtext("ACTUAL-PAYMENT", ""),
                    "overdue_amount": elem.findtext("OVERDUE-AMT", ""),
                    "write_off_amount": elem.findtext("WRITE-OFF-AMT", ""),
                    "current_balance": elem.findtext("CURRENT-BAL", ""),

                    "security_status": elem.findtext("SECURITY-STATUS", ""),
                    "original_term": elem.findtext("ORIGINAL-TERM", ""),

                    "combined_payment_history": elem.findtext(
                        "COMBINED-PAYMENT-HISTORY", ""
                    ),
                    "matched_type": elem.findtext("MATCHED-TYPE", ""),
                })

                records.append(row)
                elem.clear()

    except Exception as e:
        print(f"❌ Error parsing {xml_file_path}: {e}")
        traceback.print_exc()

    return records



# =========================
# FILE COLLECTION
# =========================
def collect_xml_files(base_dir, start_date, end_date):
    xml_files = []
    current = start_date

    while current <= end_date:
        folder = os.path.join(base_dir, current.strftime("%d%m%Y"))
        if os.path.exists(folder):
            xml_files.extend(glob.glob(os.path.join(folder, "*.xml")))
        current += timedelta(days=1)

    return xml_files


# =========================
# WORKER
# =========================
def process_single_file(file_path):
    file_name = os.path.basename(file_path)

    application_id = ENTITY_NO_MAP.get(file_name, "")
    entity_type = ENTITY_TYPE_MAP.get(file_name, "")
    co_applicant_relation = RELATION_MAP.get(file_name, "")
    customer_no = ENTITY_customer_MAP.get(file_name, "")

    return parse_xml(
        file_path,
        application_id,
        co_applicant_relation,
        entity_type,
        customer_no
    )

# =========================
# MAIN
# =========================
if __name__ == "__main__":

    start_time = time.time()

    files = collect_xml_files(BASE_XML_DIR, START_DATE, END_DATE)

    print(f"\n📅 Date range : {START_DATE:%d-%m-%Y} to {END_DATE:%d-%m-%Y}")
    print(f"📄 Total XML files found: {len(files):,}\n")

    buffer = []
    header_written = False

    with ProcessPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = [executor.submit(process_single_file, f) for f in files]

        for future in tqdm(
            as_completed(futures),
            total=len(futures),
            desc="Processing Highmark XML",
            unit="file"
        ):
            buffer.extend(future.result())

            if len(buffer) >= BATCH_SIZE:
                pd.DataFrame(buffer, columns=CSV_COLUMNS).to_csv(
                    OUTPUT_FILE,
                    sep="|",
                    index=False,
                    mode="a",
                    header=not header_written
                )
                header_written = True
                buffer.clear()

    if buffer:
        pd.DataFrame(buffer, columns=CSV_COLUMNS).to_csv(
            OUTPUT_FILE,
            sep="|",
            index=False,
            mode="a",
            header=not header_written
        )

    print("\n✅ COMPLETED SUCCESSFULLY")
    print(f"⏱ Time taken : {(time.time() - start_time) / 60:.2f} minutes")